/**
 * @file funcoes.c
 * @brief Implementação das funções do projeto.
 */

 #include "funcoes.h"

 void inserirAntena(Antena **head, char freq, int x, int y) {
     Antena *nova = (Antena *)malloc(sizeof(Antena));
     nova->freq = freq;
     nova->x = x;
     nova->y = y;
     nova->next = *head;
     *head = nova;
 }
 
 void removerAntena(Antena **head, int x, int y) {
     Antena *tmp = *head, *prev = NULL;
     while (tmp != NULL && (tmp->x != x || tmp->y != y)) {
         prev = tmp;
         tmp = tmp->next;
     }
     if (tmp) {
         if (prev) prev->next = tmp->next;
         else *head = tmp->next;
         free(tmp);
     }
 }
 
 void carregarAntenas(const char *filename, Antena **head) {
     FILE *file = fopen(filename, "r");
     if (!file) return;
     
     size_t tamanho = 256;
     char *linha = malloc(tamanho * sizeof(char));
     if (!linha) {
         fclose(file);
         return;
     }
     
     int y = 0;
     while (fgets(linha, tamanho, file)) {
         for (int x = 0; linha[x] != '\0' && linha[x] != '\n'; x++) {
             if (linha[x] != '.') {
                 inserirAntena(head, linha[x], x, y);
             }
         }
         y++;
     }
     
     free(linha);
     fclose(file);
 }
 
 void adicionarNefasto(Nefasto **head, int x, int y) {
     Nefasto *tmp = *head;
     while (tmp) {
         if (tmp->x == x && tmp->y == y) return;
         tmp = tmp->next;
     }
     Nefasto *novo = (Nefasto *)malloc(sizeof(Nefasto));
     novo->x = x;
     novo->y = y;
     novo->next = *head;
     *head = novo;
 }
 
 void calcularNefastos(Antena *head, Nefasto **nefasto) {
     for (Antena *a1 = head; a1; a1 = a1->next) {
         for (Antena *a2 = head; a2; a2 = a2->next) {
             if (a1 == a2 || a1->freq != a2->freq) continue;
             if (a1->y == a2->y) {
                 int distancia = abs(a2->x - a1->x);
                 if (distancia != 0 && distancia % 3 == 0) {
                     int nefx = (a1->x < a2->x) ? a1->x + distancia / 3 : a2->x + distancia / 3;
                     adicionarNefasto(nefasto, nefx, a1->y);
                 }
             }
             if (a1->x == a2->x) {
                 int distancia = abs(a2->y - a1->y);
                 if (distancia != 0 && distancia % 3 == 0) {
                     int nefy = (a1->y < a2->y) ? a1->y + distancia / 3 : a2->y + distancia / 3;
                     adicionarNefasto(nefasto, a1->x, nefy);
                 }
             }
         }
     }
 }
 
 void listarAntenas(Antena *head) {
     printf("Antenas:\nFreq\tX\tY\n");
     while (head) {
         printf("%c\t%d\t%d\n", head->freq, head->x, head->y);
         head = head->next;
     }
 }
 
 void listarNefastos(Nefasto *head) {
     printf("\nLocais com efeito nefasto:\nX\tY\n");
     while (head) {
         printf("%d\t%d\n", head->x, head->y);
         head = head->next;
     }
 }