/**
 * @file funcoes.h
 * @brief Declarações das funções e estruturas do projeto.
 */

 #ifndef FUNCOES_H
 #define FUNCOES_H
 
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
 /**
  * @struct Antena
  * @brief Representa uma antena na cidade.
  */
 typedef struct Antena {
     char freq;
     int x, y;
     struct Antena *next;
 } Antena;
 
 /**
  * @struct Nefasto
  * @brief Representa um local com efeito nefasto.
  */
 typedef struct Nefasto {
     int x, y;
     struct Nefasto *next; //ponteiro para ligar uma antena a outra
 } Nefasto;
 
 void inserirAntena(Antena **head, char freq, int x, int y);
 void removerAntena(Antena **head, int x, int y); //posiçao x e y da antena
 void carregarAntenas(const char *filename, Antena **head);
 void adicionarNefasto(Nefasto **head, int x, int y);
 void calcularNefastos(Antena *head, Nefasto **nefasto);
 void listarAntenas(Antena *head);
 void listarNefastos(Nefasto *head);
 
 #endif // FUNCOES_H
 