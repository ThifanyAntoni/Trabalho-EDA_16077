/**
 * @file fase1_antenas.c
 * @brief Projeto Fase 1 - Estruturas de Dados Avançadas: Manipulação de antenas e cálculo de efeitos nefastos.
 * @author Thifany Antoni
 * @date 03/2025
 *
 * Este programa lê um mapa de antenas, armazena-as em uma lista ligada
 * e calcula as localizações afetadas (efeito nefasto) segundo as regras do enunciado.
 */
/**
 * @file main.c
 * @brief Arquivo principal do projeto.
 */

 #include "funcoes.h"

 int main() {
     Antena *listaAntenas = NULL;
     Nefasto *listaNefastos = NULL;
 
     carregarAntenas("mapa.txt", &listaAntenas);
 
     listarAntenas(listaAntenas);
 
     calcularNefastos(listaAntenas, &listaNefastos);
 
     listarNefastos(listaNefastos);
 
     return 0;
 }
 